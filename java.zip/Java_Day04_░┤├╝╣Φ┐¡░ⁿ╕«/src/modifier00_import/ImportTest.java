package modifier00_import;

import java.util.*;
import java.util.logging.Logger;
//하위 패키지는 가져오지 않는다.

public class ImportTest {

	Scanner sc = new Scanner(System.in);
	Date d;
	Logger l;

}
