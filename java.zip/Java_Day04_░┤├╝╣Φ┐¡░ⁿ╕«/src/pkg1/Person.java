package pkg1;

public class Person {
    public String pkg = "pkg1";
}
