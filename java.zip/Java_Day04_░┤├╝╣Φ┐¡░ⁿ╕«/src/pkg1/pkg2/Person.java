package pkg1.pkg2;

public class Person {
    public String pkg = "pkg1.pkg2";
}
