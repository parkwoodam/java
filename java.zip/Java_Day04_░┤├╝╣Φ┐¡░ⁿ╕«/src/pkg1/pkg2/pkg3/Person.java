package pkg1.pkg2.pkg3;

public class Person {
    public String pkg = "pkg1.pkg2.pkg3";
}
