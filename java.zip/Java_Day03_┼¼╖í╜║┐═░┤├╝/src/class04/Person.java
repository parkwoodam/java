package class04;

// 클래스 생성: class 키워드 이용
// class 클래스이름 {}
class Person {
	String name;
	int age;
	String hobby;
}
