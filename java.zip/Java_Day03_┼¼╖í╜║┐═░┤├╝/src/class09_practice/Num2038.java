package class09_practice;

public class Num2038 {

	public static void main(String[] args) {
		// Movie 인스턴스 생성
		Movie movie = new Movie();
		
		movie.id = 1;
		movie.title = "Inside Out";
		movie.director = "Kelsey Mann";
		movie.genre = "comedy";
		movie.runningTime = 102;
	}

}
