package class07;

class Dog {

	Dog(){
		System.out.println("기본생성자가 호출되었어요.");
	}
}
