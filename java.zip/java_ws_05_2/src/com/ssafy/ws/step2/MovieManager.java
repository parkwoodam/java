package com.ssafy.ws.step2;

/**
 * 영화리스트를 배열로 관리하는 클래스
 * 
 * @author
 *
 */
public class MovieManager {

	Movie[] MovieList = new Movie[100];
	int size = 0;
	int MAX_SIZE = 0;

	public void add(Movie movie) {
		if (size < 100) {
			MovieList[size] = movie;
			size++;
		}
	}

	public Movie[] getList() {
		Movie[] result = new Movie[size];
		for (int i = 0; i < size; i++) {
			result[i] = MovieList[i];
		}
		return result;
	}

	public Movie[] searchByTitle(String title) {
		int cnt = 0;
		for (int i = 0; i < this.size; i++) {
			if (MovieList[i].getTitle().contains(title)) {
				cnt++;
			}
		}
		Movie[] result = new Movie[cnt];
		int idx = 0;
		for (int i = 0; i < this.size; i++) {
			if (MovieList[i].getTitle().contains(title)) {
				result[idx] = MovieList[i];
				idx++;
			}
		}
		return result;
	}

}
