
public class Start_01_HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generatded method stub
		System.out.println("Hello World!");
	}
}
