package com.ssafy.ws.step3;

public class BookTest {
	public static void main(String[] args) {
		System.out.println("11111");
	}
}
