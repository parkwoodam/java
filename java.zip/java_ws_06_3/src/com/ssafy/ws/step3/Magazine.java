package com.ssafy.ws.step3;

public class Magazine extends Book {
	
}
