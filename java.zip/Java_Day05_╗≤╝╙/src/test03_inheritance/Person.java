package test03_inheritance;

public class Person {
	String name;
	int age;
	
	void eat() {
		System.out.println("음식을 먹습니다.");
	}
}
