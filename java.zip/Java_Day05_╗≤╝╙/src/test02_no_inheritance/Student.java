package test02_no_inheritance;

public class Student {
	String name;
	int age;
	String major;
	
	void eat() {
		System.out.println("음식을 먹습니다.");
	}
	
	void study() {
		System.out.println("공부를 합니다.");
	}
}
