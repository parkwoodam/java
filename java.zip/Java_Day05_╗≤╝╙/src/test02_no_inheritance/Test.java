package test02_no_inheritance;

public class Test {
	public static void main(String[] args) {
		Person p = new Person();
//		p.
		
		Student st = new Student();
//		st.
		
	}
}
