package com.ssafy.ws.step2;

public class MovieTest {
	public static void main(String[] args) {
		Movie movie1 = new Movie();
		movie1.setId(1);
		movie1.setTitle("title1");
		movie1.setDirector("director1");
		movie1.setGenre("genre1");
		movie1.setRunningTime(120);

		Movie movie2 = new Movie(2, "title2", "director2", "genre2", 120);
		SeriesMovie seriesmovie1 = new SeriesMovie(3, "title3", "director3", "genre3", 100, 1, "episode1");
		
		MovieManager mm = new MovieManager();
		
		mm.add(movie1);
		mm.add(movie2);
		mm.add(seriesmovie1);
		
		System.out.println("**************영화리스트***************");
		Movie[] list = mm.getList();
		for (Movie m : list)
			System.out.println(m);
		
		System.out.println("***************일반 영화 추출***************");
		Movie[] movie = mm.getMovies();
		for (Movie m : movie)
			System.out.println(m);
		
		System.out.println("***************시리즈 영화 추출***************");
		SeriesMovie[] seriesmovie = mm.getSeriesMovies();
		for (SeriesMovie sm : seriesmovie)
			System.out.println(sm);
		
		System.out.println("***************제목으로 영화 검색***************");
		Movie[] searchtitle = mm.searchByTitle("title");
		for (Movie m : searchtitle)
			System.out.println(m);
	
		System.out.println("***************평균상영시간***************");
		double avg = mm.getRunningTimeAvg();
		System.out.println("평균상영시간 : " + avg + "분");
	
	}
}
