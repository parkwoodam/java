package com.ssafy.ws.step2;

/**
 * 영화리스트를 배열로 관리하는 클래스
 * 
 * @author
 *
 */
public class MovieManager {
	private final int MAX_SIZE = 100;
	private int size = 0;
	Movie[] MovieArray = new Movie[MAX_SIZE];

	public void add(Movie movie) {
		if (size < MAX_SIZE) {
			MovieArray[size++] = movie;
		} else
			System.out.println("입력이 " + MAX_SIZE + "을 넘어 더이상 추가할 수 없습니다.");
	}

	public Movie[] getList() {
		Movie[] movieList = new Movie[size];
		for (int i = 0; i < this.size; i++) {
			movieList[i] = MovieArray[i];
		}
		return movieList;
	}

	public Movie[] getMovies() {
		int cnt = 0;
		for (int i = 0; i < this.size; i++) {
			if (!(MovieArray[i] instanceof SeriesMovie)) {
				cnt++;
			}
		}
		Movie[] movie = new Movie[cnt];
		int idx = 0;
		for (int i = 0; i < this.size; i++) {
			if (!(MovieArray[i] instanceof SeriesMovie)) {
				movie[idx++] = MovieArray[i];
			}
		}
		return movie;
	}

	public SeriesMovie[] getSeriesMovies() {
		int cnt = 0;
		for (int i = 0; i < this.size; i++) {
			if (MovieArray[i] instanceof SeriesMovie) {
				cnt++;
			}
		}
		SeriesMovie[] seriesmovie = new SeriesMovie[cnt];
		int idx = 0;
		for (int i = 0; i < this.size; i++) {
			if (MovieArray[i] instanceof SeriesMovie) {
				seriesmovie[idx++] = (SeriesMovie) MovieArray[i];
			}
		}
		return seriesmovie;
	}

	public Movie[] searchByTitle(String title) {
		int cnt = 0;
		int idx = 0;
		for (int i = 0; i < this.size; i++) {
			if (MovieArray[i].getTitle().contains(title)) {
				cnt++;
			}
		}
		Movie[] searchtitle = new Movie[cnt];
		for (int i = 0; i < this.size; i++) {
			if (MovieArray[i].getTitle().contains(title)) {
				searchtitle[idx++] = MovieArray[i];
			}
		}
		return searchtitle;
	}
	
	public double getRunningTimeAvg() {
		int sum = 0;
		for (int i = 0; i < this.size; i++) {
			sum += MovieArray[i].getRunningTime();
		}
		return sum/this.size;
	}
}
