package java01_intro;

public class intro01_Hello {
	//자동완성을 적극적으로 활용!!!!
	//Ctrl + spacebar
	//main + Ctrl + spacebar
	public static void main(String[] args) {
		
		//sysout + Ctrl + spacebar
		System.out.println("Hello, World!!!");
		//Ctrl + F11
	}

}
