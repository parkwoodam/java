package java01_intro;
/**
 * 문서화 주석입니다.(마우스 올려놓을 때 표시되는 주석)
 *
 */

public class Intro02_Comment {
    
    public static void main(String[] args) {       
        // 기호가 등장한 순간부터 끝까지 해당 줄을 주석 처리 
        System.out.println("Hello"); // 이후부터 주석
        
        /*
         	여러 줄 
         	주석입니다
         */
        
        /**
         * Documentation API를 위한 주석처리
         */
    }
}
