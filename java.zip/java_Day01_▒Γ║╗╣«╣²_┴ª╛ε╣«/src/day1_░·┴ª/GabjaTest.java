package day1_과제;

import java.util.Scanner;

/**
 * 60 갑자를 서양력으로 변환하는 프로그램
 */

public class GabjaTest {

    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
    	String sibgan;
    	String sibeasy;
    	String gabja = sc.next();
    	int year = 1444;
    	
    	for (int i = 1; i <= 10; i++) {
    		  
    	}
    	
    	
    }
}
